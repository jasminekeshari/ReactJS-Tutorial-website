import React from 'react';
import { Link } from 'react-router-dom';
import { Book, Code, BookOpen, Award } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">ReactJS Tutorial</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Learn ReactJS from the ground up with our comprehensive tutorial series. 
          Master the most popular JavaScript library for building user interfaces.
        </p>
      </div>

      <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-8 rounded shadow-sm">
        <h2 className="text-xl font-semibold text-blue-800 mb-2">Getting Started</h2>
        <p className="text-gray-700">
          ReactJS is a JavaScript library created by Facebook for building user interfaces. 
          It allows developers to create large web applications that can change data without reloading the page.
        </p>
        <div className="mt-4">
          <Link 
            to="/introduction" 
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition duration-200"
          >
            Start Learning
            <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
            </svg>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 hover:shadow-lg transition duration-200">
          <div className="bg-green-100 rounded-full w-12 h-12 flex items-center justify-center mb-4">
            <Book className="text-green-600" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Beginner Friendly</h3>
          <p className="text-gray-600">
            Start from the basics and gradually build your knowledge with clear explanations and examples.
          </p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 hover:shadow-lg transition duration-200">
          <div className="bg-purple-100 rounded-full w-12 h-12 flex items-center justify-center mb-4">
            <Code className="text-purple-600" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Practical Examples</h3>
          <p className="text-gray-600">
            Learn with hands-on code examples that you can modify and experiment with directly.
          </p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 hover:shadow-lg transition duration-200">
          <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mb-4">
            <BookOpen className="text-blue-600" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Comprehensive Content</h3>
          <p className="text-gray-600">
            Cover everything from basic concepts to advanced techniques in React development.
          </p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 hover:shadow-lg transition duration-200">
          <div className="bg-amber-100 rounded-full w-12 h-12 flex items-center justify-center mb-4">
            <Award className="text-amber-600" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Best Practices</h3>
          <p className="text-gray-600">
            Learn industry standards and best practices to write clean, efficient React code.
          </p>
        </div>
      </div>

      <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Popular Topics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { title: 'Components', link: '/components' },
            { title: 'JSX', link: '/jsx' },
            { title: 'Props & State', link: '/props' },
            { title: 'Hooks', link: '/intro-hooks' },
            { title: 'Context API', link: '/context' },
            { title: 'Routing', link: '/routing' },
          ].map((topic, index) => (
            <Link 
              key={index}
              to={topic.link}
              className="p-4 bg-white rounded border border-gray-200 hover:bg-blue-50 hover:border-blue-300 transition duration-200"
            >
              {topic.title}
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;