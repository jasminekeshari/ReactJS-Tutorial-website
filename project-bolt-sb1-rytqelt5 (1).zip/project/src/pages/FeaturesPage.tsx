import React from 'react';
import NavigationButtons from '../components/NavigationButtons';
import CodeBlock from '../components/CodeBlock';

const FeaturesPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-6">
      <NavigationButtons 
        prevLink="/installation" 
        prevText="Installation"
        nextLink="/advantages-disadvantages" 
        nextText="Advantages & Disadvantages" 
      />
      
      <div className="bg-[#263238] text-white p-4 rounded-t-lg mt-6">
        <h1 className="text-2xl font-bold">ReactJS - Features</h1>
      </div>
      
      <div className="bg-white p-6 rounded-b-lg shadow-md border border-gray-200 mb-8">
        <p className="mb-6">
          React offers many outstanding features that make it a powerful JavaScript library for building user interfaces. Here are the key features that make React stand out:
        </p>
        
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-800 py-2 px-4 bg-gray-100 border-l-4 border-blue-500 mb-4">JSX (JavaScript XML)</h2>
          <div className="pl-4">
            <p className="mb-4">
              JSX is a syntax extension to JavaScript that allows you to write HTML-like code in your JavaScript files. This makes your code more readable and easier to understand.
            </p>
            <CodeBlock>
{`// JSX Example
function Greeting() {
  return (
    <div className="greeting">
      <h1>Hello, World!</h1>
      <p>Welcome to React</p>
    </div>
  );
}`}
            </CodeBlock>
            <p className="mt-4">
              JSX makes it easier to visualize the UI you're creating, and React transforms it into regular JavaScript during compilation.
            </p>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-800 py-2 px-4 bg-gray-100 border-l-4 border-green-500 mb-4">Virtual DOM</h2>
          <div className="pl-4">
            <p className="mb-4">
              React creates a lightweight representation of the real DOM in the memory, called the Virtual DOM. When there are changes to your data, React first updates the Virtual DOM and then efficiently updates only the necessary parts of the actual DOM.
            </p>
            <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-4">
              <h3 className="font-semibold text-blue-800 mb-1">How it works:</h3>
              <ol className="list-decimal pl-6 text-gray-700">
                <li>React creates a Virtual DOM when your app initializes</li>
                <li>When data changes, a new Virtual DOM is created</li>
                <li>React compares the new Virtual DOM with the previous one (diffing)</li>
                <li>Only the changed elements are updated in the real DOM</li>
              </ol>
            </div>
            <p>
              This approach significantly improves performance by minimizing direct manipulation of the DOM, which is a slow operation.
            </p>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-800 py-2 px-4 bg-gray-100 border-l-4 border-purple-500 mb-4">Component-Based Architecture</h2>
          <div className="pl-4">
            <p className="mb-4">
              React follows a component-based approach where UI elements are broken down into reusable, self-contained components. This makes your code more maintainable, reusable, and easier to test.
            </p>
            <CodeBlock>
{`// Button Component
function Button({ text, onClick }) {
  return (
    <button 
      className="primary-button" 
      onClick={onClick}
    >
      {text}
    </button>
  );
}

// Using the Button Component
function App() {
  return (
    <div>
      <h1>My App</h1>
      <Button 
        text="Click Me" 
        onClick={() => alert('Button clicked!')} 
      />
    </div>
  );
}`}
            </CodeBlock>
            <p className="mt-4">
              Components can be nested, reused, and passed properties (props) to customize their behavior and appearance.
            </p>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-800 py-2 px-4 bg-gray-100 border-l-4 border-red-500 mb-4">Unidirectional Data Flow</h2>
          <div className="pl-4">
            <p className="mb-4">
              React implements a one-way data binding, or unidirectional data flow. This means that data flows in a single direction: from parent components to child components through props.
            </p>
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
              <h3 className="font-semibold text-yellow-800 mb-1">Benefits:</h3>
              <ul className="list-disc pl-6 text-gray-700">
                <li>Makes your application more predictable</li>
                <li>Easier to debug because you know where your data comes from</li>
                <li>Improves application performance</li>
                <li>Makes your code more stable</li>
              </ul>
            </div>
            <p>
              This architecture helps maintain a clean data flow throughout your application and makes it easier to understand how changes in your data affect the UI.
            </p>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-800 py-2 px-4 bg-gray-100 border-l-4 border-yellow-500 mb-4">React Hooks</h2>
          <div className="pl-4">
            <p className="mb-4">
              Introduced in React 16.8, Hooks allow you to use state and other React features without writing a class component. This makes your code cleaner and more concise.
            </p>
            <CodeBlock>
{`import React, { useState, useEffect } from 'react';

function Counter() {
  // State Hook
  const [count, setCount] = useState(0);
  
  // Effect Hook
  useEffect(() => {
    document.title = \`You clicked \${count} times\`;
  }, [count]);
  
  return (
    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button>
    </div>
  );
}`}
            </CodeBlock>
            <p className="mt-4">
              Common React Hooks include useState, useEffect, useContext, useReducer, useCallback, useMemo, and useRef. You can also create your own custom Hooks.
            </p>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-800 py-2 px-4 bg-gray-100 border-l-4 border-teal-500 mb-4">Server-Side Rendering (SSR)</h2>
          <div className="pl-4">
            <p className="mb-4">
              React supports rendering your application on the server before sending it to the client. This improves performance and helps with SEO.
            </p>
            <div className="bg-green-50 border-l-4 border-green-400 p-4 mb-4">
              <h3 className="font-semibold text-green-800 mb-1">Advantages of SSR:</h3>
              <ul className="list-disc pl-6 text-gray-700">
                <li>Improved page load time</li>
                <li>Better search engine optimization</li>
                <li>Enhanced performance on low-powered devices</li>
                <li>Good for content-heavy applications</li>
              </ul>
            </div>
            <p>
              Frameworks like Next.js and Gatsby build on top of React to provide powerful SSR capabilities out of the box.
            </p>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-800 py-2 px-4 bg-gray-100 border-l-4 border-indigo-500 mb-4">Rich Ecosystem</h2>
          <div className="pl-4">
            <p className="mb-4">
              React has a vast ecosystem of libraries, tools, and extensions that enhance its capabilities. This rich ecosystem makes React versatile for various types of applications.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="bg-gray-50 p-3 rounded border border-gray-200">
                <h3 className="font-semibold mb-2">State Management</h3>
                <ul className="list-disc pl-6 text-sm">
                  <li>Redux</li>
                  <li>MobX</li>
                  <li>Recoil</li>
                  <li>Zustand</li>
                </ul>
              </div>
              <div className="bg-gray-50 p-3 rounded border border-gray-200">
                <h3 className="font-semibold mb-2">Routing</h3>
                <ul className="list-disc pl-6 text-sm">
                  <li>React Router</li>
                  <li>Reach Router</li>
                  <li>Next.js Routing</li>
                </ul>
              </div>
              <div className="bg-gray-50 p-3 rounded border border-gray-200">
                <h3 className="font-semibold mb-2">UI Frameworks</h3>
                <ul className="list-disc pl-6 text-sm">
                  <li>Material-UI</li>
                  <li>Chakra UI</li>
                  <li>Ant Design</li>
                  <li>Tailwind CSS</li>
                </ul>
              </div>
              <div className="bg-gray-50 p-3 rounded border border-gray-200">
                <h3 className="font-semibold mb-2">Form Handling</h3>
                <ul className="list-disc pl-6 text-sm">
                  <li>Formik</li>
                  <li>React Hook Form</li>
                  <li>Redux Form</li>
                </ul>
              </div>
            </div>
            <p>
              This ecosystem allows developers to solve complex problems without reinventing the wheel.
            </p>
          </div>
        </div>
        
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mt-8 rounded">
          <h3 className="text-lg font-semibold text-blue-800 mb-2">Why React?</h3>
          <p className="text-gray-700">
            React's features make it an excellent choice for building modern web applications. Its component-based architecture, Virtual DOM, and rich ecosystem provide a powerful foundation for developing fast, scalable, and maintainable user interfaces.
          </p>
        </div>
      </div>
      
      <NavigationButtons 
        prevLink="/installation" 
        prevText="Installation"
        nextLink="/advantages-disadvantages" 
        nextText="Advantages & Disadvantages" 
      />
    </div>
  );
};

export default FeaturesPage;