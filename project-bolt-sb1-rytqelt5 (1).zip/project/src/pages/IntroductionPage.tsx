import React from 'react';
import NavigationButtons from '../components/NavigationButtons';
import CodeBlock from '../components/CodeBlock';

const IntroductionPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-6">
      <NavigationButtons 
        nextLink="/roadmap" 
        nextText="Roadmap" 
      />
      
      <div className="bg-[#263238] text-white p-4 rounded-t-lg mt-6">
        <h1 className="text-2xl font-bold">ReactJS - Introduction</h1>
      </div>
      
      <div className="bg-white p-6 rounded-b-lg shadow-md border border-gray-200 mb-8">
        <p className="mb-4">
          React is a front-end JavaScript library developed by Facebook in 2011. 
          It follows the component based approach which helps in building reusable UI components. 
          It is used for developing complex and interactive web and mobile UI. 
          Even though it was open-sourced only in 2015, it has one of the largest communities supporting it.
        </p>
        
        <h2 className="text-xl font-bold text-gray-800 mb-3 mt-6">React Features</h2>
        
        <p className="mb-4">The major features of React are:</p>
        
        <ul className="list-disc pl-6 mb-6 space-y-2">
          <li>It uses <strong>VirtualDOM</strong> instead of RealDOM considering that RealDOM manipulations are expensive.</li>
          <li>Supports <strong>server-side rendering</strong>.</li>
          <li>Follows <strong>Unidirectional</strong> data flow or data binding.</li>
          <li>Uses <strong>reusable/composable</strong> UI components to develop the view.</li>
        </ul>
        
        <h2 className="text-xl font-bold text-gray-800 mb-3 mt-6">React Advantages</h2>
        
        <ul className="list-disc pl-6 mb-6 space-y-2">
          <li>Increases the application's performance with Virtual DOM.</li>
          <li>JSX makes code easy to read and write.</li>
          <li>React is easy to integrate with other frameworks like Meteor, Angular, etc.</li>
          <li>Using React, writing UI test cases become extremely easy.</li>
        </ul>
        
        <h2 className="text-xl font-bold text-gray-800 mb-3 mt-6">Limitations of React</h2>
        
        <ul className="list-disc pl-6 mb-6 space-y-2">
          <li>React is just a library, not a full framework.</li>
          <li>Its library is very large and takes time to understand.</li>
          <li>Coding gets complex as it uses inline templating and JSX.</li>
          <li>Novice programmers may find it difficult to understand.</li>
        </ul>
        
        <h2 className="text-xl font-bold text-gray-800 mb-3 mt-6">Installing React</h2>
        
        <p className="mb-4">React can be installed using any of the following methods:</p>
        
        <ul className="list-disc pl-6 mb-6 space-y-2">
          <li>Using <strong>npm</strong> package manager</li>
          <li>Using <strong>yarn</strong> package manager</li>
          <li>Using <strong>Create React App</strong> (CRA)</li>
        </ul>
        
        <p className="mb-4">Let's see how to install React using Create React App:</p>
        
        <CodeBlock language="bash">
{`# Using npm
npx create-react-app my-app

# Using yarn
yarn create react-app my-app`}
        </CodeBlock>
        
        <h2 className="text-xl font-bold text-gray-800 mb-3 mt-6">Hello World using React</h2>
        
        <p className="mb-4">Let's create a simple React component that displays "Hello World":</p>
        
        <CodeBlock>
{`import React from 'react';
import ReactDOM from 'react-dom';

function App() {
  return (
    <div>
      <h1>Hello World!</h1>
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById('root'));`}
        </CodeBlock>
        
        <h2 className="text-xl font-bold text-gray-800 mb-3 mt-6">React JSX</h2>
        
        <p className="mb-4">
          JSX stands for JavaScript XML. It allows us to write HTML in React. JSX makes it easier to write and add HTML in React.
        </p>
        
        <CodeBlock>
{`const element = <h1>Hello, world!</h1>;`}
        </CodeBlock>
        
        <p className="mt-4">
          This funny tag syntax is neither a string nor HTML. It is called JSX, and it is a syntax extension to JavaScript. We recommend using it with React to describe what the UI should look like.
        </p>
      </div>
      
      <NavigationButtons 
        nextLink="/roadmap" 
        nextText="Roadmap" 
      />
    </div>
  );
};

export default IntroductionPage;