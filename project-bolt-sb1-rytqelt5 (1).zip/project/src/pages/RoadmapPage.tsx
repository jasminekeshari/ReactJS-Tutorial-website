import React from 'react';
import NavigationButtons from '../components/NavigationButtons';

const RoadmapPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-6">
      <NavigationButtons 
        prevLink="/introduction" 
        prevText="Introduction"
        nextLink="/installation" 
        nextText="Installation" 
      />
      
      <div className="bg-[#263238] text-white p-4 rounded-t-lg mt-6">
        <h1 className="text-2xl font-bold">ReactJS - Roadmap</h1>
      </div>
      
      <div className="bg-white p-6 rounded-b-lg shadow-md border border-gray-200 mb-8">
        <p className="mb-6">
          This roadmap will guide you through learning React.js step by step, from the basics to advanced concepts. Follow this path to become proficient in React development.
        </p>
        
        <h2 className="text-xl font-bold text-gray-800 mb-4 mt-6 bg-gray-100 p-2">1. Fundamentals</h2>
        
        <div className="pl-4 border-l-4 border-blue-400 mb-6">
          <h3 className="text-lg font-semibold mb-2">JavaScript Basics</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>ES6+ features (arrow functions, destructuring, spread/rest operators)</li>
            <li>Array methods (map, filter, reduce)</li>
            <li>Asynchronous JavaScript (Promises, async/await)</li>
          </ul>
          
          <h3 className="text-lg font-semibold mb-2">HTML & CSS</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Semantic HTML</li>
            <li>CSS fundamentals</li>
            <li>Flexbox and Grid layouts</li>
          </ul>
        </div>
        
        <h2 className="text-xl font-bold text-gray-800 mb-4 mt-6 bg-gray-100 p-2">2. React Basics</h2>
        
        <div className="pl-4 border-l-4 border-green-400 mb-6">
          <h3 className="text-lg font-semibold mb-2">Core Concepts</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>JSX syntax</li>
            <li>Components and props</li>
            <li>State and lifecycle</li>
            <li>Event handling</li>
          </ul>
          
          <h3 className="text-lg font-semibold mb-2">Component Types</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Functional components</li>
            <li>Class components</li>
            <li>React.Fragment</li>
          </ul>
        </div>
        
        <h2 className="text-xl font-bold text-gray-800 mb-4 mt-6 bg-gray-100 p-2">3. Intermediate React</h2>
        
        <div className="pl-4 border-l-4 border-purple-400 mb-6">
          <h3 className="text-lg font-semibold mb-2">React Hooks</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>useState</li>
            <li>useEffect</li>
            <li>useContext</li>
            <li>useRef</li>
            <li>useReducer</li>
            <li>useMemo and useCallback</li>
            <li>Custom hooks</li>
          </ul>
          
          <h3 className="text-lg font-semibold mb-2">Routing</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>React Router</li>
            <li>Route parameters</li>
            <li>Nested routes</li>
            <li>Protected routes</li>
          </ul>
        </div>
        
        <h2 className="text-xl font-bold text-gray-800 mb-4 mt-6 bg-gray-100 p-2">4. Advanced React</h2>
        
        <div className="pl-4 border-l-4 border-red-400 mb-6">
          <h3 className="text-lg font-semibold mb-2">State Management</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Context API</li>
            <li>Redux</li>
            <li>Redux Toolkit</li>
            <li>Zustand</li>
            <li>Recoil</li>
          </ul>
          
          <h3 className="text-lg font-semibold mb-2">Performance Optimization</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>React.memo</li>
            <li>useCallback and useMemo</li>
            <li>Code splitting</li>
            <li>Lazy loading</li>
            <li>Virtualization</li>
          </ul>
          
          <h3 className="text-lg font-semibold mb-2">Advanced Patterns</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Render props</li>
            <li>Higher-order components</li>
            <li>Compound components</li>
            <li>Controlled vs. uncontrolled components</li>
          </ul>
        </div>
        
        <h2 className="text-xl font-bold text-gray-800 mb-4 mt-6 bg-gray-100 p-2">5. Ecosystem & Tools</h2>
        
        <div className="pl-4 border-l-4 border-yellow-400 mb-6">
          <h3 className="text-lg font-semibold mb-2">Build Tools</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Create React App</li>
            <li>Vite</li>
            <li>Webpack</li>
          </ul>
          
          <h3 className="text-lg font-semibold mb-2">Styling</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>CSS Modules</li>
            <li>Styled Components</li>
            <li>Emotion</li>
            <li>Tailwind CSS</li>
          </ul>
          
          <h3 className="text-lg font-semibold mb-2">API Integration</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Fetch API</li>
            <li>Axios</li>
            <li>React Query</li>
            <li>SWR</li>
          </ul>
          
          <h3 className="text-lg font-semibold mb-2">Testing</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Jest</li>
            <li>React Testing Library</li>
            <li>Cypress</li>
          </ul>
        </div>
        
        <h2 className="text-xl font-bold text-gray-800 mb-4 mt-6 bg-gray-100 p-2">6. Frameworks Based on React</h2>
        
        <div className="pl-4 border-l-4 border-teal-400 mb-6">
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Next.js</li>
            <li>Gatsby</li>
            <li>Remix</li>
          </ul>
        </div>
        
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mt-8 rounded">
          <h3 className="text-lg font-semibold text-blue-800 mb-2">Learning Approach</h3>
          <p className="text-gray-700">
            The best way to learn React is by building projects. Start with simple applications and gradually increase complexity as you become more comfortable with the concepts.
          </p>
        </div>
      </div>
      
      <NavigationButtons 
        prevLink="/introduction" 
        prevText="Introduction"
        nextLink="/installation" 
        nextText="Installation" 
      />
    </div>
  );
};

export default RoadmapPage;