import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import IntroductionPage from './pages/IntroductionPage';
import RoadmapPage from './pages/RoadmapPage';
import InstallationPage from './pages/InstallationPage';
import FeaturesPage from './pages/FeaturesPage';
import NotFoundPage from './pages/NotFoundPage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="introduction" element={<IntroductionPage />} />
          <Route path="roadmap" element={<RoadmapPage />} />
          <Route path="installation" element={<IntroductionPage />} />
          <Route path="features" element={<FeaturesPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;