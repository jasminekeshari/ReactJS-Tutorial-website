import React from 'react';

interface CodeBlockProps {
  children: React.ReactNode;
  language?: string;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ children, language = 'jsx' }) => {
  return (
    <div className="my-4 rounded-md overflow-hidden">
      <div className="bg-gray-800 px-4 py-2 text-xs text-gray-200">
        {language}
      </div>
      <pre className="bg-gray-900 p-4 overflow-x-auto text-white text-sm">
        <code>{children}</code>
      </pre>
    </div>
  );
};

export default CodeBlock;