import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { ChevronDown, ChevronRight } from 'lucide-react';

interface TopicSection {
  title: string;
  isSpecial?: boolean;
  topics: { name: string; path: string }[];
}

const Sidebar: React.FC = () => {
  const [openSections, setOpenSections] = useState<{ [key: string]: boolean }>({
    'ReactJS': true,
    'Hooks': true,
    'ReactJS Advanced': false,
  });

  const toggleSection = (section: string) => {
    setOpenSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const sections: TopicSection[] = [
    {
      title: 'ReactJS',
      topics: [
        { name: 'Introduction', path: '/introduction' },
        { name: 'Roadmap', path: '/roadmap' },
        { name: 'Installation', path: '/installation' },
        { name: 'Features', path: '/features' },
        { name: 'Advantages & Disadvantages', path: '/advantages-disadvantages' },
        { name: 'Architecture', path: '/architecture' },
        { name: 'Creating a React Application', path: '/creating-react-app' },
        { name: 'JSX', path: '/jsx' },
        { name: 'Components', path: '/components' },
        { name: 'Nested Components', path: '/nested-components' },
        { name: 'Using Newly Created Components', path: '/using-components' },
        { name: 'Component Collection', path: '/component-collection' },
        { name: 'Styling', path: '/styling' },
        { name: 'Properties (props)', path: '/props' },
        { name: 'Creating Components using Properties', path: '/components-with-props' },
        { name: 'props Validation', path: '/props-validation' },
        { name: 'Constructor', path: '/constructor' },
        { name: 'Component Life Cycle', path: '/component-lifecycle' },
        { name: 'Event management', path: '/event-management' },
        { name: 'Creating an Event−Aware Component', path: '/event-aware-component' },
        { name: 'Introduce Events in Expense Manager APP', path: '/events-expense-manager' },
        { name: 'State Management', path: '/state-management' },
        { name: 'State Management API', path: '/state-management-api' },
        { name: 'Stateless Component', path: '/stateless-component' },
      ]
    },
    {
      title: 'Hooks',
      isSpecial: true,
      topics: [
        { name: 'Introduction to Hooks', path: '/intro-hooks' },
        { name: 'Using useState', path: '/usestate' },
        { name: 'Using useEffect', path: '/useeffect' },
        { name: 'Using useContext', path: '/usecontext' },
        { name: 'Using useRef', path: '/useref' },
        { name: 'Using useReducer', path: '/usereducer' },
        { name: 'Using useCallback', path: '/usecallback' },
        { name: 'Using useMemo', path: '/usememo' },
        { name: 'Custom Hooks', path: '/custom-hooks' },
      ]
    },
    {
      title: 'ReactJS Advanced',
      isSpecial: true,
      topics: [
        { name: 'Accessibility', path: '/accessibility' },
        { name: 'Code Splitting', path: '/code-splitting' },
        { name: 'Context', path: '/context' },
        { name: 'Error Boundaries', path: '/error-boundaries' },
      ]
    },
    {
      title: 'Additional Concepts',
      isSpecial: true,
      topics: [
        { name: 'State Management Using React Hooks', path: '/state-hooks' },
        { name: 'Component Life Cycle Using React Hooks', path: '/lifecycle-hooks' },
        { name: 'Layout Component', path: '/layout-component' },
        { name: 'Pagination', path: '/pagination' },
        { name: 'Material UI', path: '/material-ui' },
        { name: 'Http client programming', path: '/http-client' },
        { name: 'Form Programming', path: '/form-programming' },
        { name: 'Controlled Component', path: '/controlled-component' },
        { name: 'Uncontrolled Component', path: '/uncontrolled-component' },
        { name: 'Formik', path: '/formik' },
        { name: 'Conditional Rendering', path: '/conditional-rendering' },
        { name: 'Lists', path: '/lists' },
        { name: 'Keys', path: '/keys' },
        { name: 'Routing', path: '/routing' },
        { name: 'Redux', path: '/redux' },
        { name: 'Animation', path: '/animation' },
        { name: 'Bootstrap', path: '/bootstrap' },
        { name: 'Map', path: '/map' },
        { name: 'Table', path: '/table' },
        { name: 'Managing State Using Flux', path: '/flux' },
        { name: 'Testing', path: '/testing' },
        { name: 'CLI Commands', path: '/cli-commands' },
        { name: 'Building and Deployment', path: '/building-deployment' },
        { name: 'Example', path: '/example' },
      ]
    },
    {
      title: 'ReactJS Useful Resources',
      isSpecial: true,
      topics: [
        { name: 'Quick Guide', path: '/quick-guide' },
        { name: 'Useful Resources', path: '/resources' },
        { name: 'Discussion', path: '/discussion' },
      ]
    },
    {
      title: 'Selected Reading',
      isSpecial: true,
      topics: [
        { name: 'Developer\'s Best Practices', path: '/best-practices' },
        { name: 'Effective Resume Writing', path: '/resume-writing' },
        { name: 'Computer Glossary', path: '/glossary' },
        { name: 'Who is Who', path: '/who-is-who' },
      ]
    },
  ];

  return (
    <aside className="w-full md:w-64 bg-gray-100 border-r border-gray-200 shrink-0 overflow-y-auto h-[calc(100vh-64px-96px)] md:h-auto sticky top-0">
      <div className="p-4">
        <div className="relative">
          <input 
            type="search" 
            placeholder="Search tutorials..." 
            className="w-full py-2 px-3 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>
      </div>
      
      <nav className="py-2">
        {sections.map((section) => (
          <div key={section.title} className="mb-2">
            <button
              onClick={() => toggleSection(section.title)}
              className={`flex items-center justify-between w-full px-4 py-2 text-left ${
                section.isSpecial 
                  ? 'bg-[#4d5a63] text-white font-medium' 
                  : 'text-gray-900 hover:bg-gray-200'
              }`}
            >
              <span>{section.title}</span>
              {openSections[section.title] ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </button>
            
            {openSections[section.title] && (
              <ul className="pl-4">
                {section.topics.map((topic) => (
                  <li key={topic.path}>
                    <NavLink
                      to={topic.path}
                      className={({ isActive }) =>
                        `block py-2 px-4 text-sm ${
                          isActive
                            ? 'text-blue-600 bg-blue-50 border-l-4 border-blue-600'
                            : 'text-gray-700 hover:bg-gray-200'
                        }`
                      }
                    >
                      {topic.name}
                    </NavLink>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;