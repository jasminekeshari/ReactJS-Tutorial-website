import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface NavigationButtonsProps {
  prevLink?: string;
  prevText?: string;
  nextLink?: string;
  nextText?: string;
}

const NavigationButtons: React.FC<NavigationButtonsProps> = ({
  prevLink,
  prevText,
  nextLink,
  nextText,
}) => {
  return (
    <div className="flex justify-between items-center py-4">
      {prevLink && (
        <Link
          to={prevLink}
          className="flex items-center px-4 py-2 bg-[#4d5a63] text-white rounded hover:bg-[#36414a] transition duration-200"
        >
          <ChevronLeft className="mr-2 h-4 w-4" />
          Previous Topic: {prevText}
        </Link>
      )}
      {!prevLink && <div />}
      
      {nextLink && (
        <Link
          to={nextLink}
          className="flex items-center px-4 py-2 bg-[#4d5a63] text-white rounded hover:bg-[#36414a] transition duration-200"
        >
          Next Topic: {nextText}
          <ChevronRight className="ml-2 h-4 w-4" />
        </Link>
      )}
    </div>
  );
};

export default NavigationButtons;